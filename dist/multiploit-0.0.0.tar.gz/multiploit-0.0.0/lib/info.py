def version():
    print("The version of multiploit is 1.0.0")
